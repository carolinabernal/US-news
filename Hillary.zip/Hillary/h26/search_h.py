# Import the necessary package to process data in JSON format
try:
    import json
except ImportError:
    import simplejson as json

# Import the necessary methods from "twitter" library
from twitter import Twitter, OAuth, TwitterHTTPError

# Variables that contains the user credentials to access Twitter API
ACCESS_TOKEN = '239975265-O503ejQ2tuo0xwzV61weVENgvgsgJeHKJzz1iykH'
ACCESS_SECRET = 'bOpsAgRscAkXpvGrQWmxuKUrE8W822FXuu6abxBM43i8i'
CONSUMER_KEY = 'GR2cYySpruyeRmgrQQNuEU8c0'
CONSUMER_SECRET = 'ThlRpJhdTkxmbTMIQFhr6iCOktmxRyBDM5koXiihkKIB4gs4JV'


oauth = OAuth(ACCESS_TOKEN, ACCESS_SECRET, CONSUMER_KEY, CONSUMER_SECRET)
twitter = Twitter(auth=oauth)

listA = ('tuscaloosanews', 'dothaneagle','arizonarepublic', 'TucsonStar', 'nwademgaz', 'TimesRecord', 'latimes', 'sfchronicle', 'denverpost', 'csgazette', 'hartfordcourant', 'nhregister')
for i in listA:
    j = twitter.search.tweets(q='Hillary OR Clinton from:'+i+' since:2016-11-26 until:2016-11-27 filter:links -@'+i+'', count='100')
    file_name=i+".json"
    with open(file_name,"w") as out:
        out.write(json.dumps(j, indent=4))

listB = ('NewsWilmington', 'Doverpost', 'orlandosentinel', 'MiamiHerald', 'ajc', 'GwinnettDaily','MidWeekHawaii', 'StarAdvertiser','IdahoStatesman', 'twinfallstn','chicagotribune', 'Suntimes')
for i in listB:
    j = twitter.search.tweets(q='Hillary OR Clinton from:'+i+' since:2016-11-26 until:2016-11-27 filter:links -@'+i+'', count='100')
    file_name=i+".json"
    with open(file_name,"w") as out:
        out.write(json.dumps(j, indent=4))

listC = ('indystar', 'nwi', 'DMRegister', 'gazettedotcom', 'kansasdotcom', 'CJOnline','courierjournal', 'heraldleader','theadvocatebr', 'shreveporttimes', 'sunjournal', 'PortlandPhoenix')
for i in listC:
    j = twitter.search.tweets(q='Hillary OR Clinton from:'+i+' since:2016-11-26 until:2016-11-27 filter:links -@'+i+'', count='100')
    file_name=i+".json"
    with open(file_name,"w") as out:
        out.write(json.dumps(j, indent=4))

listD = ('baltimoresun', 'Baltimore_Times', 'BostonGlobe', 'bostonherald','freep', 'detroitnews', 'StarTribune', 'PioneerPress','clarionledger', 'DJournalnow','KCStar', 'stltoday',)
for i in listD:
    j = twitter.search.tweets(q='Hillary OR Clinton from:'+i+' since:2016-11-22 until:2016-11-23 filter:links -@'+i+'', count='100')
    file_name=i+".json"
    with open(file_name,"w") as out:
        out.write(json.dumps(j, indent=4))

# with open("output24.csv","w") as out:
#     for i in listI:
#         info = json.load(open(i+".json"))
#         counter = 0
#         for tweet in info['statuses']:
#             text = tweet['text']
#             if not text.startswith('RT'):
#                 print(text)
#                 counter += 1
#         out.write("{} , {}\n".format(i,counter))
